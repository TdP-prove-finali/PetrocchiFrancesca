package biblioteca;


import java.net.URL;
import java.time.Month;
import java.util.Collections;
import java.util.Comparator;
import java.util.Map;
import java.util.ResourceBundle;
import java.util.TreeMap;

import biblioteca.model.BibliotecaModel;
import biblioteca.sim.OutOfStock;
import biblioteca.sim.Simulatore;
import biblioteca.sim.Statistiche;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Slider;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;

public class BibliotecaController {
	
	private BibliotecaModel model;
	private Simulatore sim;
	private Map<String, Integer> acquisti;
	private Month mese;
	private double percent;
	private int restituzione;

	public void setModel(BibliotecaModel model) {
		this.model=model;
	}
	
    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;

    @FXML
    private Button btnAggiungi;
    
    @FXML
    private Button btnRimuovi;
    
    @FXML
    private Button btnSimulaAgain;
    
    @FXML
    private Button btnSimula;

    @FXML
    private Slider sliderCapienza;   

    @FXML
    private ComboBox<Month> boxMese;
    
    @FXML
    private ComboBox<Integer> boxRestituzione;

    @FXML
    private ComboBox<String> boxLibro;
    
    @FXML
    private TextField txtCopie;
    
    @FXML
    private TextArea txtResult; 
    
    @FXML
    private TableView<OutOfStock> tableOOS;

    @FXML
    private TableColumn<OutOfStock, String> columnID;

    @FXML
    private TableColumn<OutOfStock, String> columnAutore;

    @FXML
    private TableColumn<OutOfStock, String> columnTitolo;

    @FXML
    private TableColumn<OutOfStock, String> columnOOS;
    
    // Avvia una nuova simulazione
    @FXML
    void doSimula(ActionEvent event) {
    	txtResult.clear();
    	acquisti = new TreeMap<String, Integer>();
    	mese = this.boxMese.getValue();
    	percent = this.sliderCapienza.getValue();
    	boolean flag = true;
    	if(mese==null){
    		this.txtResult.appendText("Selezionare il mese dell'anno da sottoporre a simulazione.\n");
    		flag = false;
    	}
    	if(this.boxRestituzione.getValue()!=null)
    		this.restituzione = boxRestituzione.getValue();
    	else{
    		this.txtResult.appendText("Selezionare la variabilità nei tempi di restituzione.\n");
    		flag = false;
    	}
    	if(percent==0){
    		txtResult.appendText("Selezionare la percentuale di libri disponibili in biblioteca al momento di inizio simulazione.\n");
    		flag = false;
    	}
    	if (flag){
    		sim = new Simulatore(model, mese, percent/100, restituzione, acquisti);
    		txtResult.setText(this.print());
    		this.printTable();
    			
    		this.boxLibro.setDisable(false);
    		this.txtCopie.setDisable(false);
    		this.btnAggiungi.setDisable(false);
    		this.btnRimuovi.setDisable(false);
    		this.btnSimulaAgain.setDisable(false);
    
    		this.boxLibro.getItems().clear();
    		this.boxLibro.getItems().addAll(sim.getStat().getDisastri().keySet());
    	}
    }
    
	// Simula l'acquisto di nuove copie:
    @FXML
    void doAggiungi(ActionEvent event) {
    	String idTitolo = this.boxLibro.getValue();
    	String copie = this.txtCopie.getText();
    	if(idTitolo==null || copie.equals(""))
    		txtResult.appendText("Seleziona dal menù l'id del libro che intendi acquistare e specifica il numero di copie.\n");
    	else{
    		try{
    			int c = Integer.parseInt(copie.trim());
    			if(!acquisti.containsKey(idTitolo)){
    				acquisti.put(idTitolo, c);
    				txtResult.appendText(idTitolo+" +"+c+" copie;\n");
    			}
    			else{
    				int n = acquisti.remove(idTitolo);
    				acquisti.put(idTitolo, n+c);
    				txtResult.appendText(idTitolo+" +"+(c+n)+" copie in totale;\n");
    			}
    		} catch(NumberFormatException nfe){
    			nfe.printStackTrace();
    			txtResult.appendText("Specifica correttamente il numero di copie che desideri acquistrare.\n");
    		}
    	}
    	this.txtCopie.clear();
    }
    
	// Storna gli acquisti
    @FXML
    void doRimuovi(ActionEvent event) {
    	String idTitolo = this.boxLibro.getValue();
    	String copie = this.txtCopie.getText();
    	if(idTitolo==null || copie.equals(""))
    		txtResult.appendText("Seleziona dal menù l'id del libro di cui intendi stornare l'acquisto e specifica il numero di copie.\n");
    	else{
    		try{
    			int c = Integer.parseInt(copie.trim());
    			if(!acquisti.containsKey(idTitolo)){
    				txtResult.appendText("Non hai ancora acquistato nessuna nuova copia di questo libro.\n");
    			}
    			else{
    				int n = acquisti.remove(idTitolo);
    				if((n-c)>0){
    						acquisti.put(idTitolo, n-c);
    				        txtResult.appendText(idTitolo+" +"+(n-c)+" copie in totale;\n");
    				}
    				else
    					txtResult.appendText(idTitolo+" 0 copie acquistate;\n");
    			}
    		} catch(NumberFormatException nfe){
    			nfe.printStackTrace();
    			txtResult.appendText("Specifica correttamente il numero di copie che desideri acquistrare.\n");
    		}
    	}
    	this.txtCopie.clear();
    }
    
	// Riprova la simulazione aggiornando la quantità di libri disponibili
    @FXML
    void doSimulaAgain(ActionEvent event) {
    	mese = this.boxMese.getValue();
    	percent = this.sliderCapienza.getValue();
    	boolean flag = true;
    	if(mese==null){
    		this.txtResult.appendText("Selezionare il mese dell'anno da sottoporre a simulazione.\n");
    		flag = false;
    	}
    	if(this.boxRestituzione.getValue()!=null)
    		this.restituzione = boxRestituzione.getValue();
    	else{
    		this.txtResult.appendText("Selezionare la variabilità nei tempi di restituzione.\n");
    		flag = false;
    	}
    	if(percent==0){
    		txtResult.appendText("Selezionare la percentuale di libri disponibili in biblioteca al momento di inizio simulazione.\n");
    		flag = false;
    	}
    	if(flag){
    		sim = new Simulatore(model, mese, percent/100, restituzione, acquisti);
    		txtResult.appendText("\n"+this.print());
    		this.printTable();
    			
    		this.txtCopie.clear();
    		for(String id : sim.getStat().getDisastri().keySet()){
    			if(!this.boxLibro.getItems().contains(id))
    				boxLibro.getItems().add(id);
    		}
    		Collections.sort(boxLibro.getItems(), new Comparator<String>(){
   			public int compare(String a, String b){
    			return a.compareTo(b);
    			}
  		    });
    	}
    }
    
    
    // Metodi per la stampa dei risultati
    
    private String print(){
    	Statistiche stat = sim.getStat();
    	String oosRate = String.format("%.2f", stat.getPercentualeDisastri());
    	String stampa = "Simulazione dei movimenti della Biblioteca di Ingegneria per il mese di "+this.monthConvertor(mese)+
		" assumendo una disponibilità del "+(int)percent+"% e una variabilità dei tempi di restituzione di al massimo "+this.restituzione+" giorni:\n"
		+ "• "+stat.getMovimenti()+" movimenti registrati di cui "+stat.getPrestiti()+" richieste di prestito;\n"
		+ "• "+stat.getLibriDiversi()+" libri diversi chiesti in prestito;\n"
		+ "• "+stat.getMancatiPrestiti()+" richieste di prestito non evase ("+oosRate+"%);\n"
		+ "• "+stat.getDisastri().size()+" libri diversi non disponibili quando richiesti.\n\n";
    	if(stat.getMancatiPrestiti()!=0){
    		stampa+= "Selezionare dal menù i libri di cui si desidera acquistare nuove copie, specificandone il numero.\n"
	    	+ "Per stornare gli acquisti cliccare su \"Rimuovi\".\n"
		    + "Per avviare un'altra simulazione con le copie aggiuntive cliccare su \"Nuova Simulazione\".\n";
    	}
		return stampa;
    }
    
    private void printTable(){
        ObservableList<OutOfStock> oos = FXCollections.observableArrayList();
        oos.addAll(sim.getStat().getDisastri().values());
        Collections.sort(oos);
        this.tableOOS.setItems(oos);
    }
    
	public String monthConvertor(Month m){
		switch(m){
		case APRIL:
			return "aprile";
		case AUGUST:
			return "agosto";
		case DECEMBER:
			return "dicembre";
		case FEBRUARY:
			return "febbraio";
		case JANUARY:
			return "gennaio";
		case JULY:
			return "luglio";
		case JUNE:
			return "giugno";
		case MARCH:
			return "marzo";
		case MAY:
			return "maggio";
		case NOVEMBER:
			return "novembre";
		case OCTOBER:
			return "ottobre";
		case SEPTEMBER:
			return "settembre";
		default:
			System.err.println("ERRORE CONVERSIONE MONTH->STRING");
			return "ERRORE";		
		}
	}

    @FXML
    void initialize() {
        assert btnAggiungi != null : "fx:id=\"btnAggiungi\" was not injected: check your FXML file 'Biblioteca.fxml'.";
        assert tableOOS != null : "fx:id=\"tableOOS\" was not injected: check your FXML file 'Biblioteca.fxml'.";
        assert columnID != null : "fx:id=\"columnID\" was not injected: check your FXML file 'Biblioteca.fxml'.";
        assert columnAutore != null : "fx:id=\"columnAutore\" was not injected: check your FXML file 'Biblioteca.fxml'.";
        assert columnTitolo != null : "fx:id=\"columnTitolo\" was not injected: check your FXML file 'Biblioteca.fxml'.";
        assert columnOOS != null : "fx:id=\"columnOOS\" was not injected: check your FXML file 'Biblioteca.fxml'.";
        assert btnRimuovi != null : "fx:id=\"btnRimuovi\" was not injected: check your FXML file 'Biblioteca.fxml'.";
        assert sliderCapienza != null : "fx:id=\"sliderCapienza\" was not injected: check your FXML file 'Biblioteca.fxml'.";
        assert txtResult != null : "fx:id=\"txtResult\" was not injected: check your FXML file 'Biblioteca.fxml'.";
        assert boxMese != null : "fx:id=\"boxMese\" was not injected: check your FXML file 'Biblioteca.fxml'.";
        assert btnSimula != null : "fx:id=\"btnSimula\" was not injected: check your FXML file 'Biblioteca.fxml'.";
        assert btnSimulaAgain != null : "fx:id=\"btnSimulaAgain\" was not injected: check your FXML file 'Biblioteca.fxml'.";
        assert txtCopie != null : "fx:id=\"txtCopie\" was not injected: check your FXML file 'Biblioteca.fxml'.";
        assert boxLibro != null : "fx:id=\"boxLibro\" was not injected: check your FXML file 'Biblioteca.fxml'.";
        assert boxRestituzione != null : "fx:id=\"boxRestituzione\" was not injected: check your FXML file 'Biblioteca.fxml'.";
        
        boxMese.getItems().clear();
		boxMese.getItems().addAll(Month.values());
		
		boxRestituzione.getItems().clear();
		boxRestituzione.getItems().addAll(0, 1, 2, 3, 4, 5, 6, 7);
		
		this.inizTable();
    }
    
    private void inizTable() {
        columnOOS.setCellValueFactory(cellData -> cellData.getValue().numProperty().asString());
        columnID.setCellValueFactory(cellData -> cellData.getValue().idTitoloProperty());
        columnAutore.setCellValueFactory(cellData -> cellData.getValue().autoreProperty());
        columnTitolo.setCellValueFactory(cellData -> cellData.getValue().titoloProperty());
    }
}
