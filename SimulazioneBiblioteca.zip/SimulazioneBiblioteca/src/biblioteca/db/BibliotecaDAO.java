package biblioteca.db;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import biblioteca.bean.Libro;
import biblioteca.bean.Movimento;

public class BibliotecaDAO {
	
	// Estrae dal DB tutti i libri della biblioteca
	public Map<String, Libro> getAllBooks() {
		String query="SELECT * FROM libri";
		Map<String, Libro> libri = new TreeMap<String, Libro>();
		try{
		Connection conn=DBConnect.getConnection();
		Statement st=conn.createStatement();
		ResultSet rs=st.executeQuery(query);
		if(rs.isBeforeFirst()){
			while(rs.next()){
				String idTitolo=rs.getString("idTitolo");
				Libro l=new Libro(idTitolo, rs.getString("titolo"), rs.getString("autore"), rs.getInt("numeroCopie"));
				libri.put(idTitolo, l);
			}
		}
		conn.close();
		} catch(SQLException e){
			e.printStackTrace();
		}
		return libri;
	}


	// Estrae dal DB tutti i movimenti del mese passato come parametro
	public List<Movimento> getAllMovements(String mese) {
		String query="SELECT * FROM movimenti WHERE timestamp LIKE ?";
		List<Movimento> movimenti= new LinkedList<Movimento>();
		try{
		Connection conn=DBConnect.getConnection();
		PreparedStatement st=conn.prepareStatement(query);
		st.setString(1, "2015-"+mese+"-%");
		ResultSet rs=st.executeQuery();
		if(rs.isBeforeFirst()){
			while(rs.next()){
				Movimento p=new Movimento(rs.getInt("id"), rs.getString("idTitolo"), rs.getString("idCopia"), rs.getString("tipo"), rs.getTimestamp("timestamp").toLocalDateTime());
				movimenti.add(p);
			}
		}
		conn.close();
		} catch(SQLException e){
			e.printStackTrace();
		}
		return movimenti;
	}

}
