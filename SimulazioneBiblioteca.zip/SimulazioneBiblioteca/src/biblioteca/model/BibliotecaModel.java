package biblioteca.model;


import java.time.Month;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import biblioteca.bean.Libro;
import biblioteca.bean.Movimento;
import biblioteca.db.BibliotecaDAO;

public class BibliotecaModel {
	BibliotecaDAO dao;
	Map<String, Libro> libri;
	
	public BibliotecaModel(){
		dao = new BibliotecaDAO();
		libri = new TreeMap<String, Libro>();
	}

	//Chiede al DAO tutti i libri della biblioteca
	public void getAllBooks() {
		Long time = System.nanoTime();
		libri = dao.getAllBooks();	
		System.out.println("Tempo impiegato per caricare tutti i libri: " +(System.nanoTime()-time)/(1e8));	
	}
	
	//Crea una copia di tutti i libri
	public Map<String,Libro> getBooks(){
		Long time = System.nanoTime();
		Map<String, Libro> libriCopia = new TreeMap<String, Libro>();
		for(Libro l: libri.values()){
			libriCopia.put(l.getIdTitolo(), new Libro(l.getIdTitolo(), l.getTitolo(), l.getAutore(), l.getNumeroCopie()));
		}  
		System.out.println("Tempo impiegato per copiare tutti i libri: " +(System.nanoTime()-time)/(1e8));
		return libriCopia;
	}

	//Chiede al DAO tutti i movimenti registrati per il mese m
	public List<Movimento> getAllMovements(Month m) {
		Long time = System.nanoTime();
		List<Movimento> movimenti = new LinkedList<Movimento>();
		String mese = this.checkMonth(m);
		try{
			movimenti.addAll(dao.getAllMovements(mese));
			System.out.println("\nTempo impiegato per caricare tutti i movimenti: " +(System.nanoTime()-time)/(1e8));
		} catch (NullPointerException npe){
			npe.printStackTrace();
			System.err.println("Errore! Nessun movimento nel mese selezionato.");
			return null;
		}
		return movimenti;
	}
	
	public String checkMonth(Month mese){
		int m = mese.getValue();
		if(m<10)
			return "0"+m;
		else
			return ""+m;
	}
	
}
