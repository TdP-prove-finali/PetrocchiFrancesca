package biblioteca.bean;

public class Libro {
	private String idTitolo;
	private String titolo;
	private String autore;
	private int numeroCopie;
	
	public Libro(String idTitolo, String titolo, String autore, int numeroCopie) {
		super();
		this.idTitolo = idTitolo;
		this.titolo = titolo;
		this.autore = autore;
		this.numeroCopie = numeroCopie;
	}

	public String getIdTitolo() {
		return idTitolo;
	}

	public void setIdTitolo(String idTitolo) {
		this.idTitolo = idTitolo;
	}

	public String getTitolo() {
		return titolo;
	}

	public void setTitolo(String titolo) {
		this.titolo = titolo;
	}

	public String getAutore() {
		return autore;
	}

	public void setAutore(String autore) {
		this.autore = autore;
	}

	public int getNumeroCopie() {
		return numeroCopie;
	}

	public void setNumeroCopie(int numeroCopie) {
		this.numeroCopie = numeroCopie;
	}
	
	public void addCopia(){
		this.numeroCopie++;
	}
	
	public void removeCopia(){
		this.numeroCopie--;
	}

	@Override
	public String toString() {
		return idTitolo + " \"" + titolo
				+ "\" - " + autore + " (" + numeroCopie + " copie)";
	}

}
