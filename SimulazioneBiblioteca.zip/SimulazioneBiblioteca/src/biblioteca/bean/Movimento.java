package biblioteca.bean;

import java.time.LocalDateTime;

public class Movimento implements Comparable<Movimento>{
	private int id;
	private String idTitolo;
	private String idCopia;
	private EventType tipo;
	private LocalDateTime timestamp;
	
	public enum EventType{
		PRESTITO,
		RESTITUZIONE,
	}

	public Movimento(int id, String idTitolo, String idCopia, String tipo, LocalDateTime timestamp) {
		super();
		this.id = id;
		this.idTitolo = idTitolo;
		this.idCopia = idCopia;
		this.timestamp = timestamp;
		this.setTipo(tipo);
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getIdTitolo() {
		return idTitolo;
	}

	public void setIdTitolo(String idTitolo) {
		this.idTitolo = idTitolo;
	}

	public String getIdCopia() {
		return idCopia;
	}

	public void setIdCopia(String idCopia) {
		this.idCopia = idCopia;
	}

	public EventType getTipo() {
		return tipo;
	}
	
	public void setTipo(String tipo){
		if(tipo.equalsIgnoreCase("prestito"))
			this.tipo = EventType.PRESTITO;
		else if(tipo.equalsIgnoreCase("restituzione"))
			this.tipo = EventType.RESTITUZIONE;
		else
			throw new ClassCastException("Tipo di evento sconosciuto: \""+tipo+"\"");
	}

	public LocalDateTime getTimestamp() {
		return timestamp;
	}

	public void setTimestamp(LocalDateTime timestamp) {
		this.timestamp = timestamp;
	}
	
	public int compareTo(Movimento p) {
		return this.timestamp.compareTo(p.timestamp);
	}

	@Override
	public String toString() {
		return timestamp+" "+tipo+", idTitolo=" + idTitolo+ " - idCopia=" + idCopia;
	}

}
