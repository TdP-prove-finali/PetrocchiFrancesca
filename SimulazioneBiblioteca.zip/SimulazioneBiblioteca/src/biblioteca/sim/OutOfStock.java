package biblioteca.sim;

import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

public class OutOfStock implements Comparable<OutOfStock>{
	private IntegerProperty num;
	private StringProperty idTitolo;
	private StringProperty titolo;
	private StringProperty autore;
	
	public OutOfStock(String idTitolo, String titolo, String autore) {
		super();
		this.num = new SimpleIntegerProperty(0);
		this.idTitolo = new SimpleStringProperty(idTitolo);
		this.titolo = new SimpleStringProperty(titolo);
		this.autore = new SimpleStringProperty(autore);
	}

	public Integer getNum() {
		return num.get();
	}

	public void setNum(int num) {
		this.num.set(num);;
	}
	
	public IntegerProperty numProperty(){
		return num;
	}
	
	public void add(){
		int n = this.num.get()+1;
		this.num.set(n);		
	}
	
	public String getIdTitolo(){
		return idTitolo.get();
	}

	public StringProperty idTitoloProperty() {
		return idTitolo;
	}

	public void setIdTitolo(String idTitolo) {
		this.idTitolo.set(idTitolo);
	}
	
	public String getTitolo() {
		return titolo.get();
	}
	
	public StringProperty titoloProperty(){
		return titolo;
	}

	public void setTitolo(String titolo) {
		this.titolo.set(titolo);
	}

	public String getAutore(){
		return autore.get();
	}
	
	public StringProperty autoreProperty() {
		return autore;
	}

	public void setAutore(String autore) {
		this.autore.set(autore);
	}

	@Override
	public int compareTo(OutOfStock o) {
		// TODO Auto-generated method stub
		return o.num.get()-this.num.get();
	}
	
}
