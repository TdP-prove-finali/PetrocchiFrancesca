package biblioteca.sim;

import java.time.Month;
import java.util.Collections;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.PriorityQueue;
import java.util.Queue;
import java.util.Random;
import java.util.TreeMap;

import biblioteca.bean.*;
import biblioteca.bean.Movimento.EventType;
import biblioteca.model.BibliotecaModel;

public class Simulatore {
	
	private double disponibilita;
	private int variabilitaRestituzione;
	
	private Statistiche stat;
	
	private List<String> ammanchi;
	private Map<String, Libro> libri;
	private Map<String, Integer> acquisti;
	private List<Movimento> movimenti;
	private Queue<Movimento> eventList;

	public Simulatore (BibliotecaModel model, Month mese, double disponibilita, int variabilitaRestituzione, Map<String, Integer> acquisti){
		this.disponibilita = disponibilita;
		this.variabilitaRestituzione = variabilitaRestituzione;
		this.acquisti = acquisti;
		
		this.ammanchi = new LinkedList<String>();
		this.libri = new TreeMap<String, Libro>();
		this.eventList = new PriorityQueue<Movimento>();
		this.movimenti = new LinkedList<Movimento>();
		this.stat = new Statistiche();
				
		this.movimenti.addAll(model.getAllMovements(mese));
		this.libri.putAll(model.getBooks());
		this.stat.setMovimenti(movimenti.size());
				
		this.buildBiblio();
		this.buildQueue();
	    						
		Long time = System.nanoTime();

		while(this.moreEvents()){
		   this.step();
		}
		
		System.out.println("\nTempo impiegato per la simulazione: " +(System.nanoTime()-time)/(1e8));

	}

	// Ricalcola la disponibilità in biblioteca in base a acquisti e percentuale di capienza 
	private void buildBiblio(){
		Long time = System.nanoTime();
		if(!acquisti.isEmpty())
			this.setAcquisti();
		List<String> libriTemp = new LinkedList<String>();
		for(Libro l : libri.values()){
			for(int i=0; i<l.getNumeroCopie(); i++)
				libriTemp.add(l.getIdTitolo());
		}
		Collections.shuffle(libriTemp);
		int tot = libriTemp.size();
		int out = (int) (tot - tot*this.disponibilita);
		Random rand = new Random();
		for(int i=0; i<out; i++){
			String id = libriTemp.remove(rand.nextInt(tot));
			libri.get(id).removeCopia();
			tot--;
		}
		System.out.println("Tempo impiegato per costruire la biblioteca: " +(System.nanoTime()-time)/(1e8));
	}

	// Aggiorna le quantità disponibili per ogni libro secondo gli acquisti fatti
	private void setAcquisti(){
		System.out.println("*ACQUISTI*");
		for(String id : acquisti.keySet()){
			Libro l = libri.get(id);
			l.setNumeroCopie(l.getNumeroCopie()+acquisti.get(id));
			System.out.println(l.getIdTitolo()+" +"+acquisti.get(id)+" copie");
		}
	}
	
	// Genera una coda di movimenti aggiungendo variabilità stocastica ai tempi di restituzione.
	private void buildQueue() {
		Random rand = new Random();
		for(Movimento pr : movimenti){
			if(pr.getTipo()==EventType.RESTITUZIONE){
				if(this.variabilitaRestituzione!=0)
					pr.setTimestamp(pr.getTimestamp().plusDays(rand.nextInt(this.variabilitaRestituzione)));
			}
			else
				stat.addPrestito();
			eventList.add(pr);
		}		
	}

	public void step(){
		
		Movimento p = eventList.poll();
		String id = p.getIdTitolo();
		Libro l = libri.get(id);
		int copie = l.getNumeroCopie();
		System.out.print("\n"+p);
				
		switch(p.getTipo()){	
		case PRESTITO:
			if(copie>0){
				l.removeCopia();
				System.out.print(" => evaso correttamente.");
			}
			else{
				System.out.print(" => !DISASTRO!");
				stat.addDisastro(l);
				ammanchi.add(id);
			}
			stat.addLibro(id);
			break;	
		case RESTITUZIONE:
			if(ammanchi.remove(id))
				System.out.print(" => Il prestito non è mai avvenuto, no restituzione.");
			else{
				l.addCopia();
				System.out.print(" => riconsegnato correttamente.");
			}
			break;
			
		default:
			System.out.print("Caso non contemplato.");
			throw new RuntimeException();
			
		}		
	}

	public boolean moreEvents(){
		return !eventList.isEmpty();
	}
	
	public Statistiche getStat() {
		return stat;
	}

}
