package biblioteca.sim;

import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

import biblioteca.bean.Libro;

public class Statistiche {
	private Map<String, OutOfStock> disastri;
	private Set<String> libri;
	private int mancatiPrestiti;
	private int movimenti;
	private int prestiti;
	
	public Statistiche(){
		disastri = new TreeMap<String, OutOfStock>();
		libri = new HashSet<String>();		
		prestiti = 0;
		mancatiPrestiti = 0;
		movimenti = 0;
	}
	
	public void addDisastro(Libro l){
		if(!disastri.containsKey(l.getIdTitolo()))
			disastri.put(l.getIdTitolo(), new OutOfStock(l.getIdTitolo(), l.getTitolo(), l.getAutore()));
		disastri.get(l.getIdTitolo()).add();
		mancatiPrestiti++;
	}
	
	public double getPercentualeDisastri(){
		double p =(double)mancatiPrestiti/prestiti;
		return p*100;
	}
	
	public Map<String, OutOfStock> getDisastri() {
		return disastri;
	}

	public int getMovimenti() {
		return movimenti;
	}

	public void setMovimenti(int movimenti) {
		this.movimenti = movimenti;
	}

	public int getPrestiti() {
		return prestiti;
	}

	public void addPrestito(){
		prestiti++;
	}

	public void addLibro(String l){
		if(!libri.contains(l))
			libri.add(l);
	}
	
	public int getLibriDiversi(){
		return libri.size();
	}
	
	public int getMancatiPrestiti(){
		return mancatiPrestiti;
	}

}
